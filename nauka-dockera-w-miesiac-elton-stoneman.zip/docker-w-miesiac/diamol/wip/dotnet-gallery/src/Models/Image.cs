namespace ImageGallery.Models
{
    public class Image
    {
        public string Url {get; set;}
        public string Caption {get; set;}
        public string Copyright {get; set;}
    }
}