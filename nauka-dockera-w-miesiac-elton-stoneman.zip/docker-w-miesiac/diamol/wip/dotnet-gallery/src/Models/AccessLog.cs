namespace ImageGallery.Models
{
    public class AccessLog
    {
        public string ClientIp {get; set;}
    }
}