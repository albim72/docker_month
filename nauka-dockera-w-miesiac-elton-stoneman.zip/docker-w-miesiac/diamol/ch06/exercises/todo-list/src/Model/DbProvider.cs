namespace ToDoList.Model
{
    public enum DbProvider
    {
        Sqlite = 0,

        Postgres
    }
}
