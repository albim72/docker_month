# Rozdział 14. - Laboratorium - Przykładowe rozwiązanie

Wykonaj wdrożenie stosu i sprawdź wszystkie repliki:

```
docker stack deploy -c image-gallery.yml image-gallery

docker stack ps image-gallery
```

Sprawdź czy usługa API jest prawidłowo skonfigurowana i działa zgodnie z oczekiwaniami:

```
docker service inspect --pretty image-gallery_iotd

docker service ps image-gallery_iotd
```

Zaktualizuj stos do wersji drugiej (v2), dołączając do polecenia odpowiednie pliki Compose:

```
docker-compose -f image-gallery.yml -f v2.yml --log-level ERROR config > stack.yml

docker stack deploy -c stack.yml image-gallery

docker service ps image-gallery_iotd
```

Powinieneś zobaczyć wyniki pokazujące, że proces wprowadzenia nowej wersji przebiegł zgodnie z oczekiwaniami; jeśli nowa wersja aplikacji został następnie wycofana, to być może będziesz musiał zmodyfikować testy stanu, tak by aplikacja miała więcej czasu na przesłanie odpowiedzi.

Poniżej pokazałem wynik, jaki uzyskałem dziś wykonując to laboratorium, jest naprawdę spektakularny:

![Mgławica Nietoperza](solution.png)
