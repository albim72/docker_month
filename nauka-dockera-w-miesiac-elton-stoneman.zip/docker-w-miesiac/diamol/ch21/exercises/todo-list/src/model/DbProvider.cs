namespace ToDoList.Model
{
    public enum DbProvider
    {
        Postgres = 0
    }
}
