# Rozdział 17. - Laboratorium - Przykładowe rozwiązanie

Optymalizacja pliku Dockerfile instalującego Docker CLI.

## Wersja dla systemu Linux

Pierwotny plik [Dockerfile](linux/Dockerfile) używa systemu Debian i działa zgodnie z oficjalnymi instrukcjami instalacji Dockera.
To działanie jest prawidłowe, jednak my potrzebujemy  jedynie Docker CLI (interfejs wiersza poleceń), więc cała reszta jest nipotrzebna - niezoptymalzowana wersja obrazu zajmuje 970MB.

Mój plik [Dockerfile.optimized](linux/Dockerfile.optimized) ignoruje oficjalne wytyczne. Jest to wieloetapowy plik budowy, który używa dystrybucji Alpine Linux i instaluje jedynie pakiet Docker CLI. Ostatni etap pliku bodowy kopiuje jedynie plik binarny Docker CLI - zoptymaizowany obraz ma wielkość 75.3MB.

## Wersja dla systemu Windows

Pierwotny plik [Dockerfile](windows/Dockerfile) używa Windows Server Core, instaluje Chocolatey i używa Chocolatey do zainstalowania Docker. W efekcie uzyskujemy pełny pakiet Dockera, a obraz zajmuje 4.95GB.

Mój plik [Dockerfile.optimized](linux/Dockerfile.optimized) używa pierwotnego pliku Dockerfile jako pierwszego etapu wieloetapowego procesu budowy. Końcowy etap bazuje na systemie Nano Server i kopiuje do obrazu jedynie binarny plik Docker CLI (oraz niezbędne biblioteki DLL - przekonasz się, że są niezbędne kiedy spróbujesz używać Dockere baz nich). Uzyskany obraz zajmuje 320MB.
