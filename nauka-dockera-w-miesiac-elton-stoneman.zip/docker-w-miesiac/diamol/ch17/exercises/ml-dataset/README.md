

https://archive.ics.uci.edu/ml/datasets/URL+Reputation

Dataset first introduced and desrcibed in this paper:

Justin Ma, Lawrence K. Saul, Stefan Savage, and Geoffrey M. Voelker, 
Identifying Suspicious URLs: An Application of Large-Scale Online Learning 
Proceedings of the International Conference on Machine Learning (ICML), pages 681-688, Montreal, Quebec, June 2009.
