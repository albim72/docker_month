# Rozdział 12. - Laboratorium - Przykładowe rozwiązanie

Utwórz sieć i uruchom usługi:

```
docker network create --driver overlay numbers

docker service create --detach --network numbers --name numbers-api diamol/ch08-numbers-api:v3

docker service create --detach --network numbers --name numbers-web --publish 8020:80  diamol/ch08-numbers-web:v3
```

W przeglądarce wyświetl stronę http://localhost:8020 (w przypadku używania kontenerów z systemem Windows zrób to z innego komputera podłączonego do sieci lokalnej). Będzie ona podobna do strony przedstwionej poniżej:

![solution.jpg](solution.png)
