package iotd;

public class ApodImage {

    private String url;
    private String title;
    private String copyright;

    public String getUrl() {
    	return url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
    	return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

    public String getCopyright() {
    	return copyright;
    }
    
    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }
}
